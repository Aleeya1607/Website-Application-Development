from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup/', views.signup, name='signup'),
    path('cart/add-to-cart/<str:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart_detail, name='cart_detail'),
    path('cartremove-from-cart/<str:product_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('manage_reviews/', views.manage_reviews, name='manage_reviews'),
    path('manage_reviews/submit_review/<str:product_id>/', views.submit_review, name='submit_review'),
    path('product_review/<str:product_id>/', views.product_review, name='product_review'),
    path('manage_reviews/delete-review/<str:review_id>/', views.delete_review, name='delete_review'),
    path('create-order/', views.create_order, name='create_order'),
    path('order-list/', views.order_list, name='order_list'),
    path('order-detail/<str:product_id>/', views.order_detail, name='order_detail'),
    path('delete-order/<str:product_id>/', views.delete_order, name='delete_order'),
    path('product/', views.product_list, name='product_list'),
    path('product/<str:product_id>/', views.product_detail, name='product_detail'),
    
]