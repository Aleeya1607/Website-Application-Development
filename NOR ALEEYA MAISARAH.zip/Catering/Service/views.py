from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.contrib import messages
from django.http import JsonResponse, HttpResponseNotAllowed, HttpResponse
from .models import Customer, Product, Review, Order

def index(request):
    if request.method == 'POST':
        Customer_email = request.POST.get('username')
        password = request.POST.get('password')
        try:
            customer = Customer.objects.get(Customer_email=Customer_email)
            if customer.password == password:
                return redirect('product_list', Customer_usernamee=customer.pk)
            else:
                error_message = "Invalid email or password"
        except Customer.DoesNotExist:
            error_message = "Invalid email or password"
        return render(request, 'login.html', {'error_message': error_message})
    return render(request, 'login.html')

def signup(request):
    if request.method == 'POST':
        Customer_Name = request.POST.get('Customer_Name')
        Customer_phone = request.POST.get('Customer_phone')
        Customer_email = request.POST.get('Customer_email')
        password = request.POST.get('Customer_password')

        if Customer.objects.filter(Customer_email=Customer_email).exists():
            return render(request, 'signup.html', {'error_message': 'Email already exists'})

        new_customer = Customer(
            Customer_Name=Customer_Name,
            Customer_phone=Customer_phone,
            Customer_email=Customer_email,
            password=password
        )
        new_customer.save()
        return redirect('index')

    return render(request, 'signup.html')

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, Product_ID=product_id)
    cart = request.session.get('cart', {})
    
    if str(product_id) in cart:
        cart[str(product_id)]['quantity'] += 1
    else:
        cart[str(product_id)] = {
            'product_id': product.Product_ID,
            'product_name': product.Product_Name,
            'price': float(product.Price),
            'quantity': 1
        }
    request.session['cart'] = cart
    return redirect('cart_detail')

def cart_detail(request):
    cart = request.session.get('cart', {})
    total_price = sum(item['price'] * item['quantity'] for item in cart.values())
    
    for item in cart.values():
        item['total'] = item['price'] * item['quantity']  # Store the individual item total in the cart item
    
    return render(request, 'cart.html', {'cart': cart, 'total_price': total_price})

def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    if str(product_id) in cart:
        del cart[str(product_id)]
        request.session['cart'] = cart
    return redirect('cart_detail')

def submit_review(request, product_id):
    product = get_object_or_404(Product, Product_ID=product_id)
    
    if request.method == 'POST':
        username = request.POST.get('username')
        review_text = request.POST.get('review')

        # Ensure username is used to get the customer
        customer = get_object_or_404(Customer, Customer_username=username)

        review = Review(
            Customer_username=customer,
            Product_ID=product,
            Review=review_text,
            Date=timezone.now()
        )
        review.save()

        return redirect('product_review', product_id=product_id)

    return render(request, 'submit_review.html', {'product_id': product_id})

def manage_reviews(request):
    if not request.user.is_authenticated:
        messages.error(request, "You need to be logged in to manage reviews.")
        return redirect('login')  # Redirect to login if the user is not authenticated

    customers = Customer.objects.filter(Customer_email=request.user.email)

    if customers.exists():
        customer = customers.first()  # Get the first customer matching the email
    else:
        customer = None

    # Fetch all products
    products = Product.objects.all()

    # Fetch reviews associated with the current customer
    reviews = Review.objects.filter(Customer_username=customer)

    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        review_text = request.POST.get('review')

        product = get_object_or_404(Product, Product_ID=product_id)

        # Create a new Review instance
        review = Review.objects.create(
            Customer_username=customer,
            Product_ID=product,
            Review=review_text,
            Date=timezone.now()
        )
        messages.success(request, "Review added successfully!")
        return redirect('manage_reviews')

    context = {
        'customer': customer,
        'products': products,
        'reviews': reviews,
    }
    return render(request, 'manage_reviews.html', context)

def product_review(request, product_id):
    product = get_object_or_404(Product, Product_ID=product_id)
    reviews = Review.objects.filter(Product_ID=product).order_by('-Date')

    return render(request, 'product_review.html', {'product_id': product_id, 'reviews': reviews})

def delete_review(request, review_id):
    if request.method == 'DELETE':
        review = get_object_or_404(Review, id=review_id)
        review.delete()
        return JsonResponse({'message': 'Review deleted successfully'}, status=200)
    else:
        return HttpResponseNotAllowed(['DELETE'])

def create_order(request):
    cart = request.session.get('cart', {})
    if not cart:
        return redirect('cart_detail')  # Redirect to the cart if it's empty

    user = request.user  # This should get the authenticated user
    customers = Customer.objects.filter(Customer_email=user.email)  # Fetch the Customer instances using email

    if customers.exists():
        customer = customers.first()  # Get the first customer matching the email
    else:
        customer = None

    total_price = sum(item['price'] * item['quantity'] for item in cart.values())
    payment_method = request.POST.get('payment_method', 'default')  # Fetch from a form or set a default

    for item in cart.values():
        product = get_object_or_404(Product, Product_ID=item['product_id'])
        Order.objects.create(
            Customer_username=customer,
            Product_ID=product,
            Quantity=item['quantity'],
            Total_price=item['price'] * item['quantity'],
            Payment_method=payment_method
        )

    # Clear the cart after creating the order
    request.session['cart'] = {}

    return redirect('order_list', {'Total_price': total_price})


def order_list(request):
    orders = Order.objects.all()
    return render(request, 'order_list.html', {'orders': orders})

def order_detail(request, product_id):
    order = get_object_or_404(Order, Product_ID__Product_ID=product_id)
    return render(request, 'order_detail.html', {'order': order})

def delete_order(request, product_id):
    if request.method == 'DELETE':
        order = get_object_or_404(Order, Product_ID__Product_ID=product_id)
        order.delete()
        return JsonResponse({'message': 'Order deleted successfully'}, status=200)
    return HttpResponseNotAllowed(['DELETE'])

def product_list(request):
    if request.method =='GET':
        products = Product.objects.all()
    return render(request, 'product_list.html', {'products': products})

def product_detail(request, product_id):
    if request.method =='GET':
        product = get_object_or_404(Product, Product_ID=product_id)
    return render(request, 'product_detail.html', {'product': product})
