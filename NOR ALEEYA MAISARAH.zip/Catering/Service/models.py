from django.db import models

# Create your models here.
class Customer(models.Model):
    Customer_username= models.CharField(max_length=30, primary_key=True)
    Customer_Name= models.CharField(max_length=20)
    Customer_Address=models.TextField()
    Customer_email=models.EmailField()
    Customer_phone=models.CharField(max_length=12)
    password=models.CharField(max_length=30)


class Product(models.Model):
    Product_ID= models.CharField(max_length=4, primary_key=True)
    Product_Name= models.CharField(max_length=20)
    Product_description= models.TextField()
    Price=models.FloatField()

class Review(models.Model):
    Customer_username=models.ForeignKey(Customer, on_delete=models.CASCADE)
    Product_ID= models.ForeignKey(Product, on_delete=models.CASCADE)
    Review= models.CharField(max_length=30)
    Date=models.DateField()

class Order(models.Model):
    Customer_username=models.ForeignKey(Customer, on_delete=models.CASCADE)
    Product_ID= models.ForeignKey(Product, on_delete=models.CASCADE)
    Quantity=models.IntegerField()
    Total_price=models.FloatField()
    Payment_method= models.CharField(max_length=12)